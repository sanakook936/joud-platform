import styled from "styled-components";

const Form = styled.form`
  display: block;
`;

export default Form;
